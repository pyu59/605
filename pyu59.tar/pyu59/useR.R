
data = read.csv('Data/allMSN.csv')
data = data[!is.na(data[,2]),]
average = round(tapply(data[,2], data[,1], mean), 3)
write.table(t(average), 'average.txt', sep=' ', col.names=F, row.names=F)

