#!/bin/bash

rm -rf Data
rm -rf Out

mkdir Data
