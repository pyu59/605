#!/bin/bash

rm -rf Out
mkdir Out

job1=$(sbatch --output="Out/%A_%a.out" datafold.sh)
job1=$(echo $job1 | sed 's/Submitted batch job //')

job2=$(sbatch --array=1-22 --output="Out/%A_%a.out" --dependency=afterany:$job1 getData.sh)
job2=$(echo $job2 | sed 's/Submitted batch job //')

job3=$(sbatch --output="Out/%A_%a.out" --dependency=afterany:$job2 longest.sh)
job3=$(echo $job3 | sed 's/Submitted batch job //')
